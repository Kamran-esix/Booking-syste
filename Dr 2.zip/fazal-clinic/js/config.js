/* ------------------------------------------------------------------
   CLINIC SETTINGS. This is the main file to edit.
   ------------------------------------------------------------------ */
export const CONFIG = {
  /* Paste your Firebase keys here (README step 5).
     While apiKey is empty the site runs in DEMO mode (data stays in this browser). */
  firebase: {
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: ''
  },

  /* Staff logins. These emails must match the users you create in Firebase
     Authentication AND the list inside firestore.rules.
     The password is set in Firebase, never in this file. */
  staff: [
    { key: 'doctor', label: 'Doctor', email: 'doctor@drfazalwajid.com' },
    { key: 'assistant', label: 'Assistant', email: 'assistant@drfazalwajid.com' }
  ],
  /* Password used ONLY in demo mode, so you can try the admin page. */
  demoPassword: 'demo1234',

  /* Opening rules (0 = Sunday ... 6 = Saturday) */
  openWeekdays: [6, 0],
  closeMinutes: 16 * 60,   // booking for "today" stops at 4:00 PM
  daysAhead: 21,           // how far ahead patients can book
  maxPatients: 50,         // if you change this, change 50 in firestore.rules too
  holidays: [],            // extra closed dates, e.g. ['2026-12-25']

  /* Patient numbers go in blocks. Each block has its own time range. */
  perGroup: 10,
  groups: [
    ['11:30', '12:30'],    // #1  to #10
    ['12:30', '13:30'],    // #11 to #20
    ['13:30', '14:30'],    // #21 to #30
    ['14:30', '15:30'],    // #31 to #40
    ['15:30', '16:00']     // #41 to #50
  ],

  /* Contact details */
  phone: '0347 3510 292',
  phoneIntl: '923473510292',
  whatsapp: '0346 0065541',      // CHECK: the number you sent first had only 10 digits
  whatsappIntl: '923460065541',
  easypaisa: '0344 0970664',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Hassan+Medical+Complex+Kabal+Swat'
};
