import { CONFIG } from './config.js';
import * as DB from './db.js';
import { T, MONTHS, DAYS, LANGS } from './i18n.js';

const $ = (s) => document.querySelector(s);
const el = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat().forEach((c) => e.append(c));
  return e;
};

/* ---------- language ---------- */
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
};
let lang = T[store.get('fw-lang')] ? store.get('fw-lang') : 'en';
const t = (k, v = {}) => {
  let s = (T[lang] && T[lang][k]) ?? T.en[k] ?? k;
  for (const [a, b] of Object.entries(v)) s = s.replaceAll('{' + a + '}', b);
  return s;
};
const fmtDate = (d) => {
  const [, m, day] = d.split('-').map(Number);
  return `${DAYS[lang][DB.weekday(d)]} ${day} ${MONTHS[lang][m - 1]}`;
};
const timeText = (n) => DB.rangeText(n);

/* ---------- state ---------- */
const state = {
  dates: DB.candidateDates(), closed: new Set(), date: null, number: null,
  taken: null, loadError: false, busy: false, last: loadLast(),
  heroDate: null, heroTaken: null
};
let unTaken = () => {}, unHero = () => {};

function loadLast() {
  try {
    const x = JSON.parse(store.get('fw-last') || 'null');
    return x && x.date >= DB.todayKHI() ? x : null;
  } catch (e) { return null; }
}
const isClosed = (d) => state.closed.has(d) || DB.isHoliday(d);
const firstOpen = () => state.dates.find((d) => !isClosed(d)) || null;

/* ---------- rendering ---------- */
function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'en' ? 'ltr' : 'rtl';
  document.querySelectorAll('[data-i18n]').forEach((n) => { n.textContent = t(n.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((n) => { n.placeholder = t(n.dataset.i18nPh); });
  $('#langs').replaceChildren(...LANGS.map(([code, label]) =>
    el('button', { type: 'button', 'aria-pressed': String(code === lang), lang: code, onclick: () => { lang = code; store.set('fw-lang', code); applyLang(); } }, label)));
  $('#paySend').textContent = t('pay_s3', { num: CONFIG.whatsapp });
  renderAll();
}

function renderAll() { renderDates(); renderBoard(); renderChosen(); renderHero(); renderReceipt(); renderPay(); }

function renderDates() {
  const host = $('#dates');
  host.replaceChildren();
  $('#noDates').hidden = state.dates.length > 0;
  for (const d of state.dates) {
    const closed = isClosed(d);
    const [, m, day] = d.split('-').map(Number);
    host.append(el('button', { type: 'button', class: 'chip', disabled: closed, 'aria-pressed': String(d === state.date), onclick: () => selectDate(d) },
      el('span', {}, DAYS[lang][DB.weekday(d)]), el('strong', {}, `${day} ${MONTHS[lang][m - 1]}`), closed ? el('em', {}, t('closed')) : ''));
  }
}

function renderBoard() {
  const host = $('#board');
  host.replaceChildren();
  if (!state.date) return;
  if (state.taken === null && !state.loadError) { host.append(el('p', { class: 'muted' }, t('loading'))); return; }
  const per = CONFIG.perGroup;
  CONFIG.groups.forEach((g, gi) => {
    const from = gi * per + 1, to = Math.min(from + per - 1, CONFIG.maxPatients);
    let free = 0;
    const nums = el('div', { class: 'nums' });
    for (let n = from; n <= to; n++) {
      const tk = state.taken ? state.taken.has(n) : false;
      if (!tk) free++;
      nums.append(el('button', {
        type: 'button', class: 'num', disabled: tk, 'aria-pressed': String(n === state.number),
        'aria-label': `#${n}, ${t(tk ? 'taken' : 'free')}, ${timeText(n)}`, onclick: () => pick(n)
      }, String(n)));
    }
    host.append(el('div', { class: 'blk' },
      el('div', { class: 'blk-h' }, el('b', { dir: 'ltr' }, timeText(from)), el('span', {}, `#${from}–#${to} · ${free ? t('free_count', { n: free }) : t('full')}`)),
      nums));
  });
}

function renderChosen() {
  const btn = $('#submit'), c = $('#chosen');
  btn.disabled = state.busy || !state.number || !state.date;
  if (!state.number) { c.textContent = ''; btn.textContent = t('pick_hint'); return; }
  c.textContent = t('chosen', { n: state.number, date: fmtDate(state.date), time: timeText(state.number) });
  btn.textContent = t('confirm', { n: state.number });
}

function firstFree(taken) {
  for (let n = 1; n <= CONFIG.maxPatients; n++) if (!taken.has(n)) return n;
  return null;
}
function renderHero() {
  const num = $('#heroNum'), when = $('#heroWhen');
  if (!state.heroDate) { num.textContent = '#–'; when.textContent = t('no_dates'); return; }
  if (state.heroTaken === null) { num.textContent = '#–'; when.textContent = fmtDate(state.heroDate); return; }
  const n = firstFree(state.heroTaken);
  if (n === null) { num.textContent = '–'; when.textContent = t('next_full', { date: fmtDate(state.heroDate) }); return; }
  num.textContent = '#' + n;
  when.textContent = `${fmtDate(state.heroDate)} · ${timeText(n)}`;
}

function renderReceipt() {
  const host = $('#receipt'), wiz = $('#wizard'), b = state.last;
  host.hidden = !b; wiz.hidden = !!b;
  host.replaceChildren();
  if (!b) return;
  host.append(el('div', { class: 'receipt' },
    el('h3', {}, t('conf_h')),
    el('p', { class: 'muted' }, t('conf_num')),
    el('p', { class: 'big' }, '#' + b.number),
    el('dl', {},
      el('dt', {}, t('name')), el('dd', {}, b.name),
      el('dt', {}, t('loc')), el('dd', {}, b.location),
      el('dt', {}, t('day_l')), el('dd', {}, fmtDate(b.date)),
      el('dt', {}, t('approx')), el('dd', { dir: 'ltr' }, timeText(b.number))),
    el('p', { class: 'muted' }, t('conf_note')),
    el('div', { class: 'row' },
      el('a', { class: 'btn', href: '#pay' }, t('conf_pay')),
      el('button', { class: 'btn ghost', type: 'button', onclick: () => { state.last = null; store.set('fw-last', ''); selectDate(firstOpen()); renderAll(); } }, t('conf_new')))));
}

function waLink(text) { return `https://wa.me/${CONFIG.whatsappIntl}?text=${encodeURIComponent(text)}`; }
function renderPay() {
  $('#epNum').textContent = CONFIG.easypaisa;
  const b = state.last;
  const text = b ? t('wa_msg', { name: b.name, n: b.number, date: fmtDate(b.date) }) : t('wa_msg_plain');
  $('#payWa').href = waLink(text);
  $('#waFloat').href = `https://wa.me/${CONFIG.whatsappIntl}`;
  $('#mapBtn').href = CONFIG.mapsUrl;
  $('#phoneTxt').textContent = CONFIG.phone;
  $('#waTxt').textContent = CONFIG.whatsapp;
  $('#callBtn').href = 'tel:+' + CONFIG.phoneIntl;
}

/* ---------- actions ---------- */
function showMsg(id, text) { const m = $(id); m.textContent = text || ''; m.hidden = !text; }

function selectDate(d) {
  unTaken();
  state.date = d; state.number = null; state.taken = null; state.loadError = false;
  showMsg('#formMsg', '');
  renderDates(); renderBoard(); renderChosen();
  if (!d) return;
  unTaken = DB.watchTaken(d, (set, err) => {
    if (d !== state.date) return;
    state.loadError = !!err; state.taken = set;
    showMsg('#boardMsg', err ? t('err_load') : '');
    if (state.number && set.has(state.number)) {
      showMsg('#formMsg', t('err_taken', { n: state.number }));
      state.number = null;
    }
    renderBoard(); renderChosen();
  });
}

function pick(n) {
  state.number = state.number === n ? null : n;
  showMsg('#formMsg', '');
  renderBoard(); renderChosen();
}

let heroStarted = false;
function startHero() {
  const d = firstOpen();
  if (heroStarted && d === state.heroDate) return;
  heroStarted = true;
  unHero(); state.heroDate = d; state.heroTaken = null; renderHero();
  if (!d) return;
  unHero = DB.watchTaken(d, (set) => { state.heroTaken = set; renderHero(); });
}

$('#form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (state.busy || !state.number) return;
  const name = $('#name').value.trim(), location = $('#loc').value.trim();
  if (name.length < 2 || location.length < 2) { showMsg('#formMsg', t('err_fields')); (name.length < 2 ? $('#name') : $('#loc')).focus(); return; }
  const date = state.date, number = state.number;
  state.busy = true; renderChosen(); showMsg('#formMsg', '');
  try {
    await DB.book(date, number, name, location);
    state.last = { date, number, name, location };
    store.set('fw-last', JSON.stringify(state.last));
    state.number = null;
    $('#form').reset();
    renderAll();
    $('#book').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    const code = err && err.message;
    showMsg('#formMsg', code === 'taken' ? t('err_taken', { n: number }) : code === 'closed' ? t('err_closed') : code === 'invalid' ? t('err_fields') : t('err_gen'));
    if (code === 'taken') state.number = null;
  } finally {
    state.busy = false; renderBoard(); renderChosen();
  }
});

$('#copyBtn').addEventListener('click', async () => {
  const b = $('#copyBtn'), num = CONFIG.easypaisa.replace(/\s/g, '');
  try { await navigator.clipboard.writeText(num); b.textContent = t('copied'); }
  catch (e) { const r = document.createRange(); r.selectNodeContents($('#epNum')); const s = getSelection(); s.removeAllRanges(); s.addRange(r); b.textContent = t('copied'); }
  setTimeout(() => { b.textContent = t('copy'); }, 2000);
});

/* ---------- start ---------- */
if (DB.isDemo) $('#demoBar').hidden = false;
applyLang();
DB.watchClosed((set) => {
  state.closed = set;
  if (!state.date || isClosed(state.date)) selectDate(firstOpen()); else renderDates();
  startHero();
});
