/* ------------------------------------------------------------------
   Data layer: the only file that knows about Firebase.
   - Demo mode (no apiKey): data lives in this browser, so you can test.
   - Live mode: Firestore, updates in real time on every screen.

   Firestore layout
     slots/{date}_{number}      public: just says "this number is taken"
     bookings/{date}_{number}   private: patient name + location (staff only)
     closedDays/{date}          public: clinic closed on this date
   ------------------------------------------------------------------ */
import { CONFIG } from './config.js';

export const isDemo = !CONFIG.firebase.apiKey;
const FB = 'https://cdn.jsdelivr.net/npm/firebase@10.12.2/';
const TZ = 'Asia/Karachi';

/* ---------- dates (always Pakistan time, as YYYY-MM-DD) ---------- */
export const todayKHI = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date());

export function minutesKHI() {
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
  const get = (t) => +p.find((x) => x.type === t).value;
  return (get('hour') % 24) * 60 + get('minute');
}
const ymd = (d) => d.split('-').map(Number);
export const weekday = (d) => { const [y, m, x] = ymd(d); return new Date(Date.UTC(y, m - 1, x)).getUTCDay(); };
export const addDays = (d, n) => { const [y, m, x] = ymd(d); return new Date(Date.UTC(y, m - 1, x + n)).toISOString().slice(0, 10); };
export const isHoliday = (d) => CONFIG.holidays.includes(d);

/* Open weekdays from today onward (closed days are marked by the page, not removed). */
export function candidateDates() {
  const today = todayKHI(), out = [];
  for (let i = 0; i <= CONFIG.daysAhead; i++) {
    const d = addDays(today, i);
    if (!CONFIG.openWeekdays.includes(weekday(d))) continue;
    if (i === 0 && minutesKHI() >= CONFIG.closeMinutes) continue;
    out.push(d);
  }
  return out;
}

export const groupOf = (n) => CONFIG.groups[Math.floor((n - 1) / CONFIG.perGroup)];
export function fmt12(hhmm) {
  let [h, m] = hhmm.split(':').map(Number);
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${String(m).padStart(2, '0')} ${ap}`;
}
export const rangeText = (n) => { const g = groupOf(n); return `${fmt12(g[0])} – ${fmt12(g[1])}`; };
export const slotId = (d, n) => `${d}_${n}`;

const clean = (s, max) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, max);

/* ================================================================
   DEMO MODE
   ================================================================ */
const KEY = 'fw-clinic-demo-v1';
let mem = { bookings: {}, closed: [] };
const subs = new Set();
const authSubs = new Set();
let demoUser = null;

function demoLoad() {
  try { const s = localStorage.getItem(KEY); if (s) { mem = JSON.parse(s); return; } } catch (e) { /* storage blocked */ }
  const d = candidateDates()[0];
  if (d) {
    [[1, 'Kamran Khan', 'Mingora'], [2, 'Sample patient', 'Kabal'], [4, 'Sample patient', 'Matta'],
     [7, 'Sample patient', 'Barikot'], [12, 'Sample patient', 'Charbagh']].forEach(([n, name, location]) => {
      mem.bookings[slotId(d, n)] = { date: d, number: n, name, location, status: 'booked' };
    });
  }
  demoSave(false);
}
function demoSave(notify = true) {
  try { localStorage.setItem(KEY, JSON.stringify(mem)); } catch (e) { /* storage blocked */ }
  if (notify) subs.forEach((f) => f());
}
function demoWatch(fn) { subs.add(fn); fn(); return () => subs.delete(fn); }
if (isDemo) {
  demoLoad();
  try { window.addEventListener('storage', (e) => { if (e.key === KEY) { demoLoad(); subs.forEach((f) => f()); } }); } catch (e) { /* ignore */ }
  try { const u = sessionStorage.getItem('fw-demo-user'); if (u) demoUser = JSON.parse(u); } catch (e) { /* ignore */ }
}

/* ================================================================
   LIVE MODE (Firebase), loaded only when needed
   ================================================================ */
let _fs, _au;
const fs = () => _fs || (_fs = (async () => {
  const [a, f] = await Promise.all([import(FB + 'app/+esm'), import(FB + 'firestore/+esm')]);
  const app = a.initializeApp(CONFIG.firebase);
  return { f, db: f.getFirestore(app), app };
})());
const au = () => _au || (_au = (async () => {
  const { app } = await fs();
  const m = await import(FB + 'auth/+esm');
  return { m, auth: m.getAuth(app) };
})());

function lazy(setup, onErr) {
  let un = () => {}, dead = false;
  setup().then((u) => { if (dead) u(); else un = u; }).catch((e) => onErr && onErr(e));
  return () => { dead = true; un(); };
}

/* ================================================================
   PUBLIC API
   ================================================================ */

/* cb(Set of taken numbers, error?) */
export function watchTaken(date, cb) {
  if (isDemo) return demoWatch(() => cb(new Set(Object.values(mem.bookings).filter((b) => b.date === date).map((b) => b.number))));
  return lazy(async () => {
    const { f, db } = await fs();
    return f.onSnapshot(f.query(f.collection(db, 'slots'), f.where('date', '==', date)),
      (snap) => cb(new Set(snap.docs.map((d) => d.data().number))),
      (err) => cb(new Set(), err));
  }, (err) => cb(new Set(), err));
}

/* cb(Set of closed dates) */
export function watchClosed(cb) {
  if (isDemo) return demoWatch(() => cb(new Set(mem.closed)));
  return lazy(async () => {
    const { f, db } = await fs();
    return f.onSnapshot(f.collection(db, 'closedDays'), (snap) => cb(new Set(snap.docs.map((d) => d.id))), () => cb(new Set()));
  }, () => cb(new Set()));
}

/* Throws Error('taken') | Error('closed') | Error('invalid') */
export async function book(date, number, name, location) {
  name = clean(name, 80); location = clean(location, 120);
  if (name.length < 2 || location.length < 2) throw new Error('invalid');
  if (isHoliday(date)) throw new Error('closed');
  const id = slotId(date, number);

  if (isDemo) {
    if (mem.closed.includes(date)) throw new Error('closed');
    if (mem.bookings[id]) throw new Error('taken');
    mem.bookings[id] = { date, number, name, location, status: 'booked' };
    demoSave();
    return;
  }
  const { f, db } = await fs();
  const batch = f.writeBatch(db);
  batch.set(f.doc(db, 'slots', id), { date, number });
  batch.set(f.doc(db, 'bookings', id), { date, number, name, location, status: 'booked', createdAt: f.serverTimestamp() });
  try { await batch.commit(); }
  catch (e) { if (e && e.code === 'permission-denied') throw new Error('taken'); throw e; }
}

/* ================================================================
   STAFF API
   ================================================================ */
const staffByEmail = (email) => CONFIG.staff.find((s) => s.email.toLowerCase() === String(email || '').toLowerCase());

export async function login(key, password) {
  const s = CONFIG.staff.find((x) => x.key === key);
  if (!s) throw new Error('bad-password');
  if (isDemo) {
    if (password !== CONFIG.demoPassword) throw new Error('bad-password');
    demoUser = { key: s.key, label: s.label };
    try { sessionStorage.setItem('fw-demo-user', JSON.stringify(demoUser)); } catch (e) { /* ignore */ }
    authSubs.forEach((f) => f(demoUser));
    return;
  }
  const { m, auth } = await au();
  try { await m.signInWithEmailAndPassword(auth, s.email, password); }
  catch (e) { throw new Error(['auth/network-request-failed', 'auth/too-many-requests'].includes(e.code) ? e.code : 'bad-password'); }
}

export async function logout() {
  if (isDemo) {
    demoUser = null;
    try { sessionStorage.removeItem('fw-demo-user'); } catch (e) { /* ignore */ }
    authSubs.forEach((f) => f(null));
    return;
  }
  const { m, auth } = await au();
  await m.signOut(auth);
}

/* cb({key,label} | null) */
export function onAuth(cb) {
  if (isDemo) { authSubs.add(cb); cb(demoUser); return () => authSubs.delete(cb); }
  return lazy(async () => {
    const { m, auth } = await au();
    return m.onAuthStateChanged(auth, (u) => {
      const s = u && staffByEmail(u.email);
      cb(s ? { key: s.key, label: s.label } : null);
    });
  }, () => cb(null));
}

/* cb({ [number]: {name, location, status} }, error?) */
export function watchBookings(date, cb) {
  const toMap = (arr) => Object.fromEntries(arr.map((b) => [b.number, b]));
  if (isDemo) return demoWatch(() => cb(toMap(Object.values(mem.bookings).filter((b) => b.date === date))));
  return lazy(async () => {
    const { f, db } = await fs();
    return f.onSnapshot(f.query(f.collection(db, 'bookings'), f.where('date', '==', date)),
      (snap) => cb(toMap(snap.docs.map((d) => d.data()))),
      (err) => cb({}, err));
  }, (err) => cb({}, err));
}

export async function setStatus(date, number, status) {
  const id = slotId(date, number);
  if (isDemo) { if (mem.bookings[id]) { mem.bookings[id].status = status; demoSave(); } return; }
  const { f, db } = await fs();
  await f.updateDoc(f.doc(db, 'bookings', id), { status });
}

/* Cancelling frees the number for other patients. */
export async function cancel(date, number) {
  const id = slotId(date, number);
  if (isDemo) { delete mem.bookings[id]; demoSave(); return; }
  const { f, db } = await fs();
  const batch = f.writeBatch(db);
  batch.delete(f.doc(db, 'bookings', id));
  batch.delete(f.doc(db, 'slots', id));
  await batch.commit();
}

export async function setClosed(date, closed) {
  if (isDemo) { mem.closed = mem.closed.filter((d) => d !== date); if (closed) mem.closed.push(date); demoSave(); return; }
  const { f, db } = await fs();
  const ref = f.doc(db, 'closedDays', date);
  if (closed) await f.setDoc(ref, { date }); else await f.deleteDoc(ref);
}
